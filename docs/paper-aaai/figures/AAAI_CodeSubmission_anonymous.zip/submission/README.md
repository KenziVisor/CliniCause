# Voice-Conversion Cross-Domain Pipeline

Two-stage pipeline for cross-domain speech classification with speaker-centric
voice conversion as a domain-normalization step:

1. **`opensmile.py`** — extracts OpenSMILE acoustic features from raw audio
   recordings and joins them with a labels CSV, producing one labeled
   feature table per domain.
2. **`mixture_of_speakers.py`** — trains a classifier on a source domain's
   features and evaluates cross-domain generalization on a target domain,
   using a Mixture-of-Speakers (MoS) routing scheme over VCTK-converted
   versions of the target audio to counteract voice/domain shift.

---

## Requirements

```bash
pip install -r requirements.txt
```

In addition to the Python packages above, you need:

- **SMILExtract** (the openSMILE binary), obtained separately from
  [audEERING/opensmile](https://github.com/audeering/opensmile). Not bundled
  here — only the wrapper script that invokes it is.
- **Voice-conversion output**: this pipeline assumes voice-converted audio
  (e.g. via VCTK target speakers) already exists on disk in the layout
  described under Stage 2 below. Generating those conversions is a separate
  step, not part of these two scripts.

---

## Stage 1: Feature extraction (`opensmile.py`)

Runs per domain: cleans and pause-trims each recording, splits it into
fixed-length chunks, extracts OpenSMILE features per chunk via SMILExtract,
and joins the result with a labels CSV.

### Input layout

`--raw-data-dir` must contain:
- The audio files (`.wav`, `.mp3`, `.m4a`, or `.WAV`).
- Exactly one labels CSV with (at minimum) a `record_id` column.

Audio filenames are expected to follow the convention:

```
<record_date>-<record_id>-<research_name>-<conversion_code>-<format>-<chunk_number>.wav
```

(hyphen-separated). The feature-joining step parses this from the filename
SMILExtract assigns each row, so recordings must be named accordingly before
running the script.

### Parameters

`pause_limit`, `smooth_window`, `weight`, `split_length`, `max_chunks`
control pause removal and chunking. Provide them either as individual CLI
flags or via `--params-csv` pointing to a two-column `parameter,value` CSV
(see `params.example.csv` in this folder — **its values are placeholders**,
not tuned parameters; pick values appropriate to your own audio). CLI flags
take precedence over the CSV when both are given.

### Usage

```bash
export SMILEXTRACT_PATH=/path/to/SMILExtract   # or pass --smilextract-path

python opensmile.py \
  --config-path /path/to/eGeMAPSv02.conf \
  --raw-data-dir ./raw/mydomainA \
  --work-dir ./work/mydomainA \
  --results-dir ./results \
  --output-csv-name mydomainA_labeled_features.csv \
  --noise-reduction none \
  --params-csv params.example.csv
```

Run once per domain (e.g. once for the source domain, once for the target
domain, and once per VCTK-converted variant of the target domain if you want
those joined the same way).

### Output

- `<results-dir>/<output-csv-name>`: final labeled feature table.
- `<work-dir>/clean/Extracted_Features_file.csv`: raw joined features before
  final labeling (intermediate).

---

## Stage 2: Cross-domain routing (`mixture_of_speakers.py`)

Trains an OpenSMILE-feature classifier on a source domain, then evaluates it
on a target domain using a learned gate that routes each target record
through the most reliable VCTK-converted speaker voice, blended with a
global baseline speaker.

### Input layout

Under `--features_dir`:
```
Recordings/<domain>.csv
Conversions/<conversion_model>/<domain>/<domain>_ToSingle<Gender><Speaker>.csv
```
Under `--model_cache_dir`:
```
VCTK.csv   # columns: speaker_id, path — maps VCTK speaker IDs to reference audio
```

Every feature CSV must have a `record_id` column and the target label column
(name given via `--target_label`, default `LABEL`), coded as 0/1 per record.

### Usage

```bash
python mixture_of_speakers.py \
  --domain_a mydomainA --domain_b mydomainB \
  --conversion_model DiffHierVC \
  --target_label LABEL \
  --classifier catboost \
  --gate_topk 3 \
  --features_dir ./features --model_cache_dir ./models \
  --out_dir ./outputs/mydomainA_to_mydomainB
```

Quick smoke test (small speaker subset, single fold-style run):
```bash
python mixture_of_speakers.py --domain_a mydomainA --domain_b mydomainB --dry_run
```

Key flags: `--classifier {catboost,LR,MLP,RandomForest,xgboost}`,
`--gate_features {ecapa,opensmile}`, `--gate_use_converted`,
`--regularize_speaker_selection`, `--global_blend`, `--no_calibration`.
Run `python mixture_of_speakers.py --help` for the full list.

### Output

Written to `--out_dir` (default `./outputs/<domain_a>_to_<domain_b>`):
- `results_routed_vs_global.csv` — Balanced Accuracy / F1 for the routed
  (MoS) blend vs. the global baseline speaker, per fold and averaged.
- `fold_XX_preds.csv` — per-record prediction probabilities and decisions
  for each outer fold.
- `pooled_moe_predictions.csv` / `pooled_baseline_predictions.csv` —
  aggregated out-of-fold predictions.
- `routing_log.txt` — run log (speaker selection, gate training, splits).

---

## Notes

- Stage 1 and Stage 2 are independent scripts connected only by the feature
  CSV file format (`record_id` + target label + OpenSMILE `sma3`-prefixed
  columns). You can substitute your own feature-extraction step for Stage 1
  as long as it produces CSVs in that shape.
- No changes were made to either script's core algorithm during
  de-identification — only how paths, credentials, and dataset/label names
  are supplied.
