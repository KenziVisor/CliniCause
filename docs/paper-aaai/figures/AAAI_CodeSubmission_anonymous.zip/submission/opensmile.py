# -*- coding: utf-8 -*-
"""
Extracts OpenSMILE acoustic features from a folder of audio recordings.

Pipeline per input audio file: optional noise reduction -> pause removal ->
chunk splitting -> SMILExtract feature extraction -> join with a labels CSV.

See README.md in this folder for the full pipeline documentation.
"""
import argparse
import glob
import os
import shutil
import wave
import time
from itertools import chain
from pathlib import Path

import numpy as np
import pandas as pd
import scipy.io.wavfile as wavfile
import tqdm
from pyAudioAnalysis import audioBasicIO
from pyAudioAnalysis import audioSegmentation as aS
from pydub import AudioSegment

from logmmse import logmmse_from_file
from speechbrain.inference.separation import SepformerSeparation as separator
import torchaudio

REQUIRED_PARAMS = ["pause_limit", "smooth_window", "weight", "split_length", "max_chunks"]


def parse_args():
    p = argparse.ArgumentParser(
        description="Extract OpenSMILE features from a raw audio folder and join with labels."
    )
    p.add_argument("--config-path", required=True, help="Path to the OpenSMILE .conf file.")
    p.add_argument("--raw-data-dir", required=True,
                   help="Folder containing source audio files and one labels CSV.")
    p.add_argument("--work-dir", default="./work",
                   help="Root for intermediate output (processed/data/clean/output subfolders). Cleared on each run.")
    p.add_argument("--results-dir", default="./results",
                   help="Folder where the final labeled features CSV is written.")
    p.add_argument("--output-csv-name", default="labeled_features.csv",
                   help="Filename for the final labeled features CSV.")
    p.add_argument("--noise-reduction", choices=["none", "logmmse", "neuralnetwork"], default="none",
                   help="Noise reduction method to apply before pause removal.")
    p.add_argument("--smilextract-path", default=None,
                   help="Path to the SMILExtract executable. Falls back to the SMILEXTRACT_PATH env var.")

    p.add_argument("--pause-limit", type=float, default=None,
                   help="Pauses longer than this (seconds) are treated as segment boundaries.")
    p.add_argument("--smooth-window", type=float, default=None, help="Silence-removal smoothing window.")
    p.add_argument("--weight", type=float, default=None, help="Silence-removal detection weight.")
    p.add_argument("--split-length", type=float, default=None, help="Chunk length in seconds.")
    p.add_argument("--max-chunks", type=int, default=None, help="Max number of chunks per file.")
    p.add_argument("--params-csv", default=None,
                   help="Optional two-column 'parameter,value' CSV providing defaults for the "
                        "params above when not passed on the CLI. See params.example.csv.")

    return p.parse_args()


def resolve_params(args):
    csv_values = {}
    if args.params_csv:
        df = pd.read_csv(args.params_csv)
        csv_values = dict(zip(df["parameter"].astype(str), df["value"]))

    resolved = {}
    missing = []
    for name in REQUIRED_PARAMS:
        cli_value = getattr(args, name)
        if cli_value is not None:
            resolved[name] = cli_value
        elif name in csv_values:
            resolved[name] = csv_values[name]
        else:
            missing.append(name)

    if missing:
        raise SystemExit(
            f"Missing required parameter(s): {', '.join(missing)}. "
            f"Pass them via CLI flags (--{missing[0].replace('_', '-')} ...) or --params-csv "
            f"(see params.example.csv)."
        )

    resolved["max_chunks"] = int(resolved["max_chunks"])
    return resolved


def resolve_smilextract_path(args):
    path = args.smilextract_path or os.environ.get("SMILEXTRACT_PATH")
    if not path:
        raise SystemExit(
            "SMILExtract path not set. Pass --smilextract-path or set the SMILEXTRACT_PATH env var."
        )
    return str(Path(path).resolve())


args = parse_args()
params = resolve_params(args)
pause_limit = params["pause_limit"]
smooth_window = params["smooth_window"]
weight = params["weight"]
Split_length = params["split_length"]
Max_chunks = params["max_chunks"]

noise_reduction_method = args.noise_reduction
noise_reduction_model = None
if noise_reduction_method == "neuralnetwork":
    noise_reduction_model = separator.from_hparams(
        source="speechbrain/sepformer-wham-enhancement",
        savedir="pretrained_models/sepformer-wham-enhancement",
    )

save_flag = True  # pause removal flag

# ***********************************************************************************************
# paths
Path2Raw_Data = Path(args.raw_data_dir).resolve()
Path2Work = Path(args.work_dir).resolve()
Path2Processed_files = Path2Work / "processed"
Path2Clean_files = Path2Work / "clean"
Path2Data_files = Path2Work / "data"
Path2Output_files = Path2Work / "output"
Path2Results = Path(args.results_dir).resolve()
Path2OutputCSVFileForTraining = Path2Results / args.output_csv_name

for d in (Path2Processed_files, Path2Clean_files, Path2Data_files, Path2Output_files, Path2Results):
    d.mkdir(parents=True, exist_ok=True)

Opensmile_path = resolve_smilextract_path(args)
Config_path = args.config_path
Output_file = Path2Output_files / "Features.csv"

print("Raw data path:", Path2Raw_Data)
print(f"Opensmile path: {Opensmile_path}")
print(f"Config path: {Config_path}")
print(f"Output path: {Output_file}")
print(f"Output csv path: {Path2OutputCSVFileForTraining}")
# ************************************************************************************************


# ************************************************************************************************
def Remove_pauses(audio_file_path, pause_limit):
    global smooth_window
    global weight
    '''
        Remove_pauses:
        Parameters: [audio file], [pause limit] (seconds)
        Output: [audio file] with all pauses greater than [pause limit] removed
        if save_flag is True, the Output file is saved in "Data" Folder

    '''

    if audio_file_path[-4:] == '.m4a':
        '''
        convert .m4a file type to wav
        '''
        track = AudioSegment.from_file(audio_file_path, 'm4a')
        wav_filename = audio_file_path.replace('m4a', 'wav')
        track.export(wav_filename, format='wav')
        [fx, x] = audioBasicIO.read_audio_file(wav_filename)
        os.remove(wav_filename)
    else:
        [fx, x] = audioBasicIO.read_audio_file(audio_file_path)

    if save_flag:
        print(f"Removing pauses from file: {audio_file_path}")
        segmentLimits = aS.silence_removal(x, fx, 0.05, 0.05, smooth_window, weight, plot=False)
        S = [[0, 0]]
        j = 0
        S[0] = segmentLimits[0]
        for i in range(len(segmentLimits) - 1):
            # if the length of the pause is less than or equal to a given pause limit, add the
            if segmentLimits[i + 1][0] - segmentLimits[i][1] <= pause_limit:
                S[j][1] = segmentLimits[i + 1][1]
            else:
                S.append(segmentLimits[i + 1])
                j += 1
        B = list()
        for i in range(len(S)):
            B.append(x[int(fx * S[i][0]):int(fx * S[i][1])])
        B = list(chain.from_iterable(B))
        B = np.array(B)

        path = Path(audio_file_path)
        new_file_path = str(Path2Data_files / ('%s-%s.wav' % (path.stem, path.suffix[1:])))
        wavfile.write(new_file_path, fx, B)
    else:
        path = Path(audio_file_path)
        new_file_path = str(Path2Data_files / ('%s-%s.wav' % (path.stem, path.suffix[1:])))
        wavfile.write(new_file_path, fx, x)

    return new_file_path
# ************************************************************************************************


# ************************************************************************************************
def Split_audio_file(audio_file_path, Max_chunks=100, Split_length=10):
    '''
    Parameters: [audio file], [file name], [max chunks number], [split length] (seconds)
    Actions:Split the [audio file] into [max chunks number] of chunks each of [split length]
    Save each chunk into the file with the name: [file name]-[chunk number] in [Processed files] subfolder.
    '''

    [fx, x] = audioBasicIO.read_audio_file(audio_file_path)

    path = Path(audio_file_path)
    all_split_files = []

    for i in range(1, 1 + min(int(len(x) / fx / Split_length), Max_chunks)):
        new_file_path = Path2Processed_files / ('%s-%s.wav' % (path.stem, i))
        wavfile.write(new_file_path, fx, np.array(x[int(fx * (i - 1) * Split_length):int(fx * i * Split_length)]))
        all_split_files.append(new_file_path)

    return (fx, x), all_split_files
# ************************************************************************************************

def get_wav_sampling_rate(wav_file):
    try:
        with wave.open(wav_file, 'r') as wf:
            return wf.getframerate()
    except wave.Error:
        print("Error: Could not open the WAV file or file is not in WAV format.")
        return None

def get_model_sample_rate():
    return noise_reduction_model.hparams.sample_rate

# ************************************************************************************************
def clean_sound_file(audio_file_path):
    print(f"Noise reduction method: {noise_reduction_method}, file: {audio_file_path}")
    output_file = str(Path2Clean_files / Path(audio_file_path).name)
    noise_reduced_file: str
    if noise_reduction_method == 'none':
        noise_reduced_file = audio_file_path
    elif noise_reduction_method == 'logmmse':
        logmmse_from_file(input_file=audio_file_path, output_file=str(output_file))
        noise_reduced_file = output_file
    elif noise_reduction_method == 'neuralnetwork':
        # for custom file, change path
        est_sources = noise_reduction_model.separate_file(path=audio_file_path)
        torchaudio.save(output_file, est_sources[:, :, 0].detach().cpu(), get_model_sample_rate())
        noise_reduced_file = output_file
    else:
        print("Noise reduction failed...")
        raise Exception("Unsupported noise reduction method")

    print(f"Success! output file: {noise_reduced_file}")
    return noise_reduced_file
# ************************************************************************************************


# ************************************************************************************************
def Features_Extraction(Config_path, audio_file_path, Output_file, Flag):
    path = Path(audio_file_path)
    cmd = Opensmile_path + ' -C ' + Config_path + \
          ' -I ' + audio_file_path + ' -csvoutput ' + str(Output_file) + \
          ' -instname ' + path.stem + ' -headercsv ' + '1' + \
          ' -appendcsv ' + '%s' % Flag
    print(cmd)
    os.system(cmd)
    return True
# ************************************************************************************************


# ************************************************************************************************
def Extracted_Features_file(Output_file, Final_file_path):

    data = pd.read_csv(Output_file, sep=';')

    df2 = pd.DataFrame(data.values, columns=data.keys())

    Metadata = list()
    Patient_Code = list()
    Conversion_Code = list()
    Chunk_number = list()
    Record_date = list()
    Research_Name = list()
    Format = list()

    for i in df2['name']:
        print(i)
        Metadata = i.strip("'").split('-')
        print(Metadata)
        Record_date.append(Metadata[0])
        Patient_Code.append(Metadata[1])
        Conversion_Code.append(Metadata[3])
        Research_Name.append(Metadata[2])
        Format.append((Metadata[4]))
        Chunk_number.append(Metadata[5])

    df2.insert(1, 'Format', Format)
    df2.insert(1, 'Chunk_number', Chunk_number)
    df2.insert(1, 'Record_date', Record_date)
    df2.insert(1, 'Research_Name', Research_Name)
    df2.insert(1, 'record_id', Patient_Code)
    df2.insert(1, 'conversion_id', Conversion_Code)
    df2 = df2.drop('name', axis=1)
    out_path = Path(Final_file_path) / 'Extracted_Features_file.csv'
    print(f"Saving csv to {out_path}")
    df2.to_csv(out_path)

    return (df2)
# ************************************************************************************************


# ************************************************************************************************
def Labeling(Path2Raw_Data, Path2Processed_files):
    print('Changing directory to: ', Path2Raw_Data)
    os.chdir(Path2Raw_Data)
    print('Reading Labels csv file: ', (glob.glob('*.csv'))[0])
    df1 = pd.read_csv((glob.glob('*.csv'))[0])

    print('Changing directory to: ', Path2Processed_files)
    os.chdir(Path2Processed_files)
    print('Reading Extracted Features csv file: ', (glob.glob('*.csv'))[0])
    df2 = pd.read_csv((glob.glob('*.csv'))[0])
    print('Trying to Join... ')
    df1['record_id'] = df1['record_id'].astype(str)  # Convert to string
    df2['record_id'] = df2['record_id'].astype(str)  # Convert to string
    df3 = df2.join(df1.set_index('record_id'), on='record_id')
    df3 = df3.drop(df3.columns[0], axis=1)
    print('Join OK')

    print('Trying to Save the Labeled file to: ', Path2OutputCSVFileForTraining)
    Path2OutputCSVFileForTraining.parent.mkdir(parents=True, exist_ok=True)
    df3.to_csv(Path2OutputCSVFileForTraining)
    print('Done!')

    print('Final Labeled Extracted Features file is located here: ', Path2OutputCSVFileForTraining)

    return True
# ************************************************************************************************


# ************************************************************************************************
def remove_folder_contents(folder):
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        try:
            if os.path.isfile(file_path) or os.path.islink(file_path):
                os.unlink(file_path)
                print('File Deleted: %s. ' % file_path)
            elif os.path.isdir(file_path):
                shutil.rmtree(file_path)
                print('File Deleted: %s. ' % file_path)
        except Exception as e:
            print('Failed to delete %s. Reason: %s' % (file_path, e))
# ************************************************************************************************


# ************************************************************************************************
def main():

    print("Removing Temporary files...")
    remove_folder_contents(Path2Processed_files)
    remove_folder_contents(Path2Data_files)
    remove_folder_contents(Path2Output_files)
    remove_folder_contents(Path2Clean_files)

    os.chdir(Path2Raw_Data)
    print("Current Path is: ", Path2Raw_Data)

    for file in os.listdir():
        if file[-4:] == '.mp3' or file[-4:] == '.wav' or file[-4:] == '.m4a' or file[-4:] == '.WAV':
            audio_file_path = os.path.abspath(str(file)[:])
            print("audio_file_path: ", audio_file_path)
            print(f"cleaning audio in file {audio_file_path}")
            audio_file_path = clean_sound_file(audio_file_path)
            new_file_path = Remove_pauses(audio_file_path, pause_limit)
            print("new_file_path: ", new_file_path)
            Split_audio_file(new_file_path, Split_length=10)

    os.chdir(Path2Processed_files)
    flag = 0
    for file in tqdm.tqdm(glob.glob('*.wav')):
        audio_file_path = os.path.abspath(str(file))
        print(os.path.abspath(str(file)))
        Features_Extraction(Config_path, audio_file_path, Output_file, flag)
        flag = 1

    Extracted_Features_file(Output_file, Path2Clean_files)
    time.sleep(5)

    print('Starting Labeling function...')
    try:
        Labeling(Path2Raw_Data, Path2Clean_files)
    except Exception as e:
        print('Labeling Failed!')
        print(e)

    os.chdir(str(Path(__file__).resolve().parent))
# ************************************************************************************************


if __name__ == "__main__":
    main()
