"""
Routed VC speaker selection: Learned Gate (Correctness Prediction).
Only 'learned_gate' routing is supported.

Algorithm:
  1. Pick global top-K experts based on performance on val set.
  2. Train a gate (SVM) to predict per-record which speaker is correct. 
     Target: correct = 1 if (p_spk(x) >= 0.5) matches y_true(x), else 0.
  3. Weighted blend of routed prediction and global baseline prediction.

Outputs:
  - results_routed_vs_global.csv + per-fold predictions CSVs.
"""

import argparse
import logging
import os
import sys
import warnings
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any

import numpy as np
import pandas as pd

from sklearn.model_selection import StratifiedKFold
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.metrics import balanced_accuracy_score, f1_score
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.neural_network import MLPClassifier

from catboost import CatBoostClassifier
from xgboost import XGBClassifier

warnings.filterwarnings("ignore")
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["LOKY_MAX_CPU_COUNT"] = "4"

import torch
import soundfile as sf
import torchaudio

if not hasattr(torchaudio, "list_audio_backends"):
    def _list_audio_backends():
        return ["soundfile"]
    torchaudio.list_audio_backends = _list_audio_backends

from speechbrain.inference.speaker import SpeakerRecognition


# ============================================================
# Logging
# ============================================================

def setup_logging(level=logging.INFO, log_file: Optional[Path] = None):
    handlers = [logging.StreamHandler(sys.stdout)]
    if log_file is not None:
        handlers.append(logging.FileHandler(str(log_file), mode="w"))
    logging.basicConfig(
        level=level,
        format="%(asctime)s | %(levelname)s | %(message)s",
        handlers=handlers,
        force=True,
    )

logger = logging.getLogger("routed_vc_eval")


# ============================================================
# Config
# ============================================================

class ExperimentConfig:
    FEMALE_VCTK = [225, 228, 229, 230, 231, 233, 236, 239, 240, 244]
    MALE_VCTK   = [226, 227, 232, 243, 254, 256, 258, 259, 270, 273]

    RANDOM_SEED = 42

    N_THRESHOLDS = 101
    DEFAULT_TAU = 3

    def __init__(self, args_list: Optional[List[str]] = None):
        p = argparse.ArgumentParser("Routed VC Speaker Selection (Learned Gate)")

        p.add_argument("--domain_a", type=str, default="source", help="Source domain dataset name.")
        p.add_argument("--domain_b", type=str, default="target", help="Target domain dataset name.")
        p.add_argument("--conversion_model", type=str, default="DiffHierVC")
        p.add_argument("--target_label", type=str, default="LABEL",
                       help="Name of the binary target label column in the feature CSVs.")
        p.add_argument("--outer_folds", type=int, default=3)

        # learned gate params
        p.add_argument("--gate_topk", type=int, default=3, help="Global top-K speakers for learned_gate.")
        p.add_argument("--gate_features", type=str, default="ecapa", choices=["ecapa", "opensmile"],
                       help="Features to use for the routing gate: 'ecapa' or 'opensmile'.")
        p.add_argument("--gate_use_converted", action="store_true",
                       help="Extract gate embeddings from converted audio instead of raw (default: False).")
        p.add_argument("--no_calibration", action="store_true",
                       help="Disable threshold calibration and use fixed theta=0.5 (default: False).")
        p.add_argument("--classifier", type=str, default="catboost",
                       choices=["catboost", "LR", "MLP", "RandomForest", "xgboost"],
                       help="Classifier to use: 'catboost', 'LR', 'MLP', 'RandomForest', or 'xgboost'.")
        
        # speaker selection
        p.add_argument("--regularize_speaker_selection", action="store_true",
                       help="Use regularized speaker selection (BA + confidence bonus) instead of pure BA.")
        p.add_argument("--confidence_weight", type=float, default=0.1,
                       help="Weight for confidence bonus in regularized speaker selection (default: 0.1).")

        # blending routed with global mean-prob
        p.add_argument("--global_blend", type=float, default=0.5)

        # VCTK speaker embeddings
        p.add_argument("--vctk_map_csv", type=str, default=None,
                       help="Path to VCTK.csv (speaker_id,path). Default: <model_cache_dir>/VCTK.csv")
        p.add_argument("--speaker_emb_cache_name", type=str, default="vctk_ecapa_speaker_embs.npz")

        # vote calib
        p.add_argument("--tune_tau", action="store_true")
        p.add_argument("--tau_grid_max", type=int, default=5)

        # final threshold tuning (OOS on outer-val)
        p.add_argument("--final_thr_grid", type=int, default=101)
        p.add_argument("--inner_folds_thr", type=int, default=3)

        # paths
        p.add_argument("--features_dir", type=str, default="./features")
        p.add_argument("--model_cache_dir", type=str, default="./models")
        p.add_argument("--out_dir", type=str, default=None)
        p.add_argument("--dry_run", action="store_true")

        self.args = p.parse_args(args_list)
        self.TARGET_LABEL = self.args.target_label

        self.targets = self.FEMALE_VCTK + self.MALE_VCTK
        if self.args.dry_run:
            self.targets = self.targets[:2]

        self.output_dir = Path(self.args.out_dir or f"./outputs/{self.args.domain_a}_to_{self.args.domain_b}")
        self.output_dir.mkdir(parents=True, exist_ok=True)


# ============================================================
# Data utils + loader
# ============================================================

def ensure_path_column(df: pd.DataFrame) -> pd.DataFrame:
    if "path" in df.columns:
        return df
    for c in df.columns:
        if isinstance(c, str) and c.lower() == "path":
            return df.rename(columns={c: "path"})
    return df

def preprocess_df(df: pd.DataFrame, target_label: str) -> pd.DataFrame:
    df = df.apply(lambda col: col.map(lambda x: x.strip() if isinstance(x, str) else x))
    df.replace("", np.nan, inplace=True)

    cols_to_check = ["record_id", target_label]
    existing = [c for c in cols_to_check if c in df.columns]
    df.dropna(subset=existing, inplace=True)

    df[target_label] = pd.to_numeric(df[target_label], errors="coerce").astype("Int32")
    record_labels = df.groupby("record_id")[target_label].first()
    keep_ids = record_labels[record_labels.isin([0, 1])].index
    df = df[df["record_id"].isin(keep_ids)].reset_index(drop=True)
    return df

def encode_target(df: pd.DataFrame, target: str) -> None:
    if target in df.columns and df[target].dtype == "object":
        le = LabelEncoder()
        df[target] = le.fit_transform(df[target])

def subject_labels(df: pd.DataFrame, label_col: str) -> pd.Series:
    return df.groupby("record_id")[label_col].first()

class CrossDomainLoader:
    def __init__(self, cfg: ExperimentConfig):
        self.cfg = cfg
        self.features_dir = Path(cfg.args.features_dir)
        self._cache: Dict[str, pd.DataFrame] = {}

    def _key(self, domain: str, conversion_model: Optional[str], target_voice: Optional[int]) -> str:
        return f"{domain}|{conversion_model or 'RAW'}|{target_voice or 'NA'}"

    def load(self, domain: str, conversion_model: Optional[str] = None, target_voice: Optional[int] = None) -> Optional[pd.DataFrame]:
        key = self._key(domain, conversion_model, target_voice)
        if key in self._cache:
            return self._cache[key].copy()

        if conversion_model is None:
            fp = self.features_dir / "Recordings" / f"{domain}.csv"
        else:
            if target_voice is None:
                raise ValueError("target_voice required for conversion_model")
            gender_prefix = "Female" if target_voice in self.cfg.FEMALE_VCTK else "Male"
            filename = f"{domain}_ToSingle{gender_prefix}{target_voice}.csv"
            fp = self.features_dir / "Conversions" / conversion_model / domain / filename
            if not fp.exists():
                fp = self.features_dir / "Conversions" / conversion_model / filename

        if not fp.exists():
            logger.warning("Missing file: %s", fp)
            return None

        df = pd.read_csv(fp)
        df = ensure_path_column(df)
        df = preprocess_df(df, self.cfg.TARGET_LABEL)
        encode_target(df, self.cfg.TARGET_LABEL)
        self._cache[key] = df.copy()
        return df.copy()


# ============================================================
# OpenSMILE model
# ============================================================

def opensmile_feature_cols(df: pd.DataFrame) -> List[str]:
    base = [c for c in df.columns if isinstance(c, str) and "sma3" in c]
    extras = [
        "loudnessPeaksPerSec",
        "VoicedSegmentsPerSec",
        "MeanVoicedSegmentLengthSec",
        "StddevVoicedSegmentLengthSec",
        "MeanUnvoicedSegmentLength",
        "StddevUnvoicedSegmentLength",
        "equivalentSoundLevel_dBp",
    ]
    return [c for c in base + extras if c in df.columns]

class OpenSMILEClassifier:
    def __init__(self, cfg: ExperimentConfig):
        self.cfg = cfg
        self.classifier_name = cfg.args.classifier
        
        if self.classifier_name == "catboost":
            self.model = CatBoostClassifier(
                verbose=False,
                n_estimators=200,
                depth=6,
                learning_rate=0.1,
                random_seed=self.cfg.RANDOM_SEED,
                auto_class_weights="Balanced",
            )
        elif self.classifier_name == "LR":
            self.model = LogisticRegression(
                class_weight="balanced",
                random_state=self.cfg.RANDOM_SEED,
                max_iter=1000,
            )
        elif self.classifier_name == "RandomForest":
            self.model = RandomForestClassifier(
                n_estimators=200,
                max_depth=6,
                class_weight="balanced",
                random_state=self.cfg.RANDOM_SEED,
            )
        elif self.classifier_name == "MLP":
            self.model = MLPClassifier(
                hidden_layer_sizes=(100,),
                max_iter=1000,
                random_state=self.cfg.RANDOM_SEED,
            )
        elif self.classifier_name == "xgboost":
            self.model = XGBClassifier(
                n_estimators=200,
                max_depth=6,
                learning_rate=0.1,
                random_state=self.cfg.RANDOM_SEED,
            )
        else:
            raise ValueError(f"Unknown classifier: {self.classifier_name}")
            
        self.scaler = StandardScaler()
        self.feats: List[str] = []

    def train(self, df_source: pd.DataFrame) -> None:
        self.feats = opensmile_feature_cols(df_source)
        if not self.feats:
            raise ValueError("No OpenSMILE features found in source data.")
            
        X = df_source[self.feats].values
        y = df_source[self.cfg.TARGET_LABEL].astype(int).values
        
        # Scale features only for LR and MLP
        if self.classifier_name in ["LR", "MLP"]:
            X_train = self.scaler.fit_transform(X)
        else:
            X_train = X
        
        if self.classifier_name in ["MLP", "xgboost"]:
            from sklearn.utils.class_weight import compute_sample_weight
            sample_weight = compute_sample_weight(class_weight="balanced", y=y)
            try:
                self.model.fit(X_train, y, sample_weight=sample_weight)
            except TypeError:
                self.model.fit(X_train, y)
        else:
            self.model.fit(X_train, y)

    def infer_rows(self, df_rows: pd.DataFrame) -> pd.DataFrame:
        out = df_rows[["record_id", self.cfg.TARGET_LABEL]].copy()
        X = df_rows[self.feats].values
        if self.classifier_name in ["LR", "MLP"]:
            X_infer = self.scaler.transform(X)
        else:
            X_infer = X
        out["prob"] = self.model.predict_proba(X_infer)[:, 1]
        return out


# ============================================================
# ECAPA extractor
# ============================================================

class EcapaExtractor:
    def __init__(self, savedir: str, device: Optional[str] = None):
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        logger.info("Loading ECAPA-TDNN on %s...", self.device)
        self.model = SpeakerRecognition.from_hparams(
            source="speechbrain/spkrec-ecapa-voxceleb",
            savedir=savedir,
            run_opts={"device": self.device},
        )
        self.model.eval()

    def extract_one(self, path: str) -> Optional[np.ndarray]:
        if not isinstance(path, str) or not os.path.exists(path):
            return None
        try:
            wav_data, sr = sf.read(path)
            wav = torch.tensor(wav_data, dtype=torch.float32)
            if wav.ndim > 1:
                wav = wav.mean(dim=1)
            wav = wav.unsqueeze(0).to(self.device)
            lens = torch.ones(1, device=self.device)
            with torch.no_grad():
                emb = self.model.encode_batch(wav, lens)  # (1,1,192)
                emb = emb.squeeze(1).cpu().numpy()        # (1,192)
            return emb[0].astype(np.float32)
        except Exception as e:
            logger.warning("ECAPA failed for %s: %s", path, e)
            return None


# ============================================================
# Vote calibration + soft-vote prob
# ============================================================

@dataclass
class CalibResult:
    threshold: float
    tau: int
    score: float

class AggregatorCalibrator:
    def __init__(self, cfg: ExperimentConfig):
        self.cfg = cfg

    def _threshold_grid(self) -> np.ndarray:
        return np.linspace(0, 1, self.cfg.N_THRESHOLDS)

    def _tau_grid(self) -> List[int]:
        if not self.cfg.args.tune_tau:
            return [self.cfg.DEFAULT_TAU]
        return list(range(1, int(self.cfg.args.tau_grid_max) + 1))

    def aggregate_vote_pred(self, df: pd.DataFrame, prob_col: str, threshold: float, tau: int) -> Tuple[pd.Series, pd.Series]:
        tmp = df.copy()
        tmp["seg_pred"] = (tmp[prob_col] >= threshold).astype(int)
        grouped = tmp.groupby("record_id")
        counts = grouped["seg_pred"].sum()
        y_pred = (counts >= tau).astype(int)
        y_true = grouped[self.cfg.TARGET_LABEL].first()
        return y_true, y_pred

    def calibrate_vote(self, df_calib: pd.DataFrame, prob_col: str) -> CalibResult:
        if self.cfg.args.no_calibration:
            tau = self.cfg.DEFAULT_TAU
            t = 0.5
            y_true, y_pred = self.aggregate_vote_pred(df_calib, prob_col, float(t), int(tau))
            sc = balanced_accuracy_score(y_true, y_pred) if len(y_true) else 0.0
            return CalibResult(threshold=float(t), tau=int(tau), score=float(sc))

        best = CalibResult(threshold=0.5, tau=self.cfg.DEFAULT_TAU, score=-1.0)
        for tau in self._tau_grid():
            for t in self._threshold_grid():
                y_true, y_pred = self.aggregate_vote_pred(df_calib, prob_col, float(t), int(tau))
                if len(y_true) == 0:
                    continue
                sc = balanced_accuracy_score(y_true, y_pred)
                if sc > best.score:
                    best = CalibResult(threshold=float(t), tau=int(tau), score=float(sc))
        return best

def sigmoid(x: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-x))

def record_soft_vote_prob(
    df_inf: pd.DataFrame,
    record_ids: List[str],
    threshold: float,
    tau: int,
    s: float,
    prob_col: str = "prob",
) -> pd.Series:
    tmp = df_inf[["record_id", prob_col]].copy()
    tmp["above"] = (tmp[prob_col] >= float(threshold)).astype(np.int32)
    counts = tmp.groupby("record_id")["above"].sum()
    counts = counts.reindex(record_ids).fillna(0.0).astype(float)
    z = (counts.to_numpy() - float(tau)) / max(float(s), 1e-6)
    return pd.Series(sigmoid(z), index=record_ids, name="p_softvote")

def tune_final_threshold_ba(y_true: pd.Series, p: pd.Series, n_grid: int = 101) -> Tuple[float, float]:
    y = y_true.astype(int).to_numpy()
    pv = p.astype(float).to_numpy()
    best_t, best_ba = 0.5, -1.0
    for t in np.linspace(0, 1, int(n_grid)):
        yp = (pv >= t).astype(int)
        ba = balanced_accuracy_score(y, yp) if len(y) else 0.0
        if ba > best_ba:
            best_ba, best_t = float(ba), float(t)
    return best_t, best_ba


# ============================================================
# Embedding / routing helpers
# ============================================================

def softmax_rows(x: np.ndarray) -> np.ndarray:
    x = x - np.max(x, axis=1, keepdims=True)
    ex = np.exp(x)
    return ex / (np.sum(ex, axis=1, keepdims=True) + 1e-12)

def l2_normalize(X: np.ndarray, axis: int = 1) -> np.ndarray:
    denom = np.linalg.norm(X, axis=axis, keepdims=True) + 1e-12
    return X / denom

def safe_logit(p: np.ndarray) -> np.ndarray:
    p = np.clip(p, 1e-6, 1.0 - 1e-6)
    return np.log(p / (1.0 - p))


class SpeakerEmbeddingCache:
    """
    VCTK speaker embedding cache.
    Loads speaker_id->path from VCTK.csv and stores embeddings in NPZ:
      spk_ids (M,), embs (M,192) L2-normalized
    """
    def __init__(self, cfg: ExperimentConfig, ecapa: EcapaExtractor):
        self.cfg = cfg
        self.ecapa = ecapa
        self.cache_fp = Path(cfg.args.model_cache_dir) / cfg.args.speaker_emb_cache_name
        vctk_csv = cfg.args.vctk_map_csv or str(Path(cfg.args.model_cache_dir) / "VCTK.csv")
        self.vctk_csv = Path(vctk_csv)

    def load_or_build(self, speaker_ids: List[int]) -> Tuple[List[int], np.ndarray]:
        speaker_ids = [int(s) for s in speaker_ids]

        if self.cache_fp.exists():
            try:
                data = np.load(self.cache_fp, allow_pickle=False)
                spk_ids = data["spk_ids"].astype(int).tolist()
                embs = data["embs"].astype(np.float32)
                idx = {s: i for i, s in enumerate(spk_ids)}
                missing = [s for s in speaker_ids if s not in idx]
                if not missing:
                    out = np.stack([embs[idx[s]] for s in speaker_ids], axis=0)
                    return speaker_ids, out
                logger.warning("Speaker emb cache missing %d ids (e.g. %s). Rebuilding.", len(missing), missing[:3])
            except Exception as e:
                logger.warning("Failed reading speaker emb cache, rebuild. Err=%s", e)

        if not self.vctk_csv.exists():
            raise FileNotFoundError(f"VCTK.csv not found: {self.vctk_csv}")

        df = pd.read_csv(self.vctk_csv)
        if not {"speaker_id", "path"}.issubset(df.columns):
            raise ValueError("VCTK.csv must have columns: speaker_id, path")
        df["speaker_id"] = df["speaker_id"].astype(int)

        spk_embs: Dict[int, np.ndarray] = {}
        for spk in speaker_ids:
            row = df[df["speaker_id"] == spk]
            if row.empty:
                logger.warning("VCTK.csv missing speaker_id=%d", spk)
                continue
            p = str(row.iloc[0]["path"])
            e = self.ecapa.extract_one(p)
            if e is None:
                continue
            e = (e / (np.linalg.norm(e) + 1e-12)).astype(np.float32)
            spk_embs[spk] = e

        if not spk_embs:
            raise RuntimeError("No speaker embeddings could be built from VCTK.csv")

        all_ids = sorted(spk_embs.keys())
        all_embs = np.stack([spk_embs[s] for s in all_ids], axis=0).astype(np.float32)

        try:
            self.cache_fp.parent.mkdir(parents=True, exist_ok=True)
            np.savez_compressed(self.cache_fp, spk_ids=np.array(all_ids, dtype=np.int32), embs=all_embs)
            logger.info("Saved speaker emb cache: %s (n=%d)", self.cache_fp, len(all_ids))
        except Exception as e:
            logger.warning("Failed saving speaker emb cache: %s", e)

        kept = [s for s in speaker_ids if s in spk_embs]
        out = np.stack([spk_embs[s] for s in kept], axis=0).astype(np.float32)
        return kept, out


@dataclass
class SpeakerPick:
    speaker: int
    calib: CalibResult
    score_ba: float


# ============================================================
# Main experiment
# ============================================================

class RoutedOpenSmileVoteExperiment:
    def __init__(self, cfg: ExperimentConfig):
        self.cfg = cfg
        self.loader = CrossDomainLoader(cfg)
        self.calib = AggregatorCalibrator(cfg)
        self.opensmile = OpenSMILEClassifier(cfg)
        self.ecapa: Optional[EcapaExtractor] = None

    def _ensure_ecapa(self):
        if self.ecapa is None:
            self.ecapa = EcapaExtractor(savedir=self.cfg.args.model_cache_dir)

    def _record_level_embeddings(self, df_raw_b: pd.DataFrame, speaker: Optional[int] = None) -> pd.DataFrame:
        """
        Per-record routing embeddings:
          ecapa_tdnn (default): ECAPA per record from audio path (RAW or converted if speaker specified)
          opensmile: aggregated (mean) OpenSMILE features per record + StandardScaler
        
        Args:
            df_raw_b: Raw target domain data (used as fallback or when gate_use_converted=False)
            speaker: If gate_use_converted=True, use converted audio from this speaker instead of raw
        """
        gate_feats = self.cfg.args.gate_features
        use_converted = self.cfg.args.gate_use_converted and speaker is not None
        
        # Load appropriate data source
        if use_converted:
            df_source = self.loader.load(self.cfg.args.domain_b, self.cfg.args.conversion_model, speaker)
            if df_source is None or df_source.empty:
                logger.warning("Converted audio not available for speaker %d, falling back to raw", speaker)
                df_source = df_raw_b
        else:
            df_source = df_raw_b

        if gate_feats == "opensmile":
            # --- OpenSMILE Logic ---
            # 1. Identify feature columns
            feats = opensmile_feature_cols(df_source)
            if not feats:
                raise ValueError("No OpenSMILE features found for gate routing.")

            # 2. Aggregate per record (mean)
            df_agg = df_source.groupby("record_id")[feats].mean().reset_index()
            
            # 3. Scale
            scaler = StandardScaler()
            X = df_agg[feats].values
            X_scaled = scaler.fit_transform(X)

            # 4. Rename to emb_0, emb_1...
            emb_cols = [f"emb_{i}" for i in range(X_scaled.shape[1])]
            df_emb = pd.DataFrame(X_scaled, columns=emb_cols)
            df_emb["record_id"] = df_agg["record_id"]
            
            # Add labels
            s_labels = subject_labels(df_source, self.cfg.TARGET_LABEL)
            df_emb[self.cfg.TARGET_LABEL] = df_emb["record_id"].map(s_labels)

            return df_emb

        # --- ECAPA Logic (Default) ---
        if "path" not in df_source.columns:
            raise ValueError("ECAPA routing requires 'path' column.")
        df_paths = df_source.groupby("record_id").first().reset_index()
        ids = df_paths["record_id"].tolist()
        ys = df_paths[self.cfg.TARGET_LABEL].tolist()
        paths = df_paths["path"].tolist()

        # Cache naming includes speaker if using converted
        cache_suffix = f"_spk{speaker}" if use_converted else ""
        cache_path = Path(self.cfg.args.model_cache_dir) / f"ecapa_record_embs_{self.cfg.args.domain_b}{cache_suffix}.csv"
        if cache_path.exists():
            df_emb = pd.read_csv(cache_path)
            if "record_id" in df_emb.columns:
                missing = set(ids) - set(df_emb["record_id"].tolist())
                if not missing:
                    df_emb = df_emb.set_index("record_id").reindex(ids).reset_index()
                    return df_emb

        self._ensure_ecapa()

        d = 192
        emb_cols = [f"emb_{i}" for i in range(d)]
        mat = np.full((len(ids), d), np.nan, dtype=np.float32)

        for i, p in enumerate(paths):
            e = self.ecapa.extract_one(p)
            if e is None:
                continue
            e = (e / (np.linalg.norm(e) + 1e-12)).astype(np.float32)
            mat[i] = e

        df_emb = pd.DataFrame(mat, columns=emb_cols)
        df_emb["record_id"] = ids
        df_emb[self.cfg.TARGET_LABEL] = ys

        # fill missing by column mean (or 0)
        for c in emb_cols:
            m = df_emb[c].mean()
            df_emb[c] = df_emb[c].fillna(0.0 if np.isnan(m) else m)

        try:
            df_emb.to_csv(cache_path, index=False)
            logger.info("Saved record ECAPA cache: %s", cache_path)
        except Exception:
            pass

        return df_emb

    # ---------- Speaker evaluation helpers ----------

    def _regularized_speaker_selection(self, val_ids: set) -> SpeakerPick:
        """
        Select speaker with best regularized score: BA + confidence_weight * confidence.
        Confidence = mean absolute deviation of predictions from 0.5 (more confident = further from 0.5).
        This penalizes speakers with uncertain predictions.
        """
        best = None
        best_score = -np.inf
        
        for spk in self.cfg.targets:
            spk = int(spk)
            df_vc = self.loader.load(self.cfg.args.domain_b, self.cfg.args.conversion_model, spk)
            if df_vc is None or df_vc.empty:
                continue
            df_vc_val = df_vc[df_vc["record_id"].isin(val_ids)].copy()
            if df_vc_val.empty:
                continue

            df_inf = self.opensmile.infer_rows(df_vc_val)
            calib_res = self.calib.calibrate_vote(df_inf, "prob")

            tmp = df_inf.copy()
            tmp["seg_pred"] = (tmp["prob"] >= calib_res.threshold).astype(int)
            counts = tmp.groupby("record_id")["seg_pred"].sum()
            y_pred = (counts >= calib_res.tau).astype(int)
            y_true = tmp.groupby("record_id")[self.cfg.TARGET_LABEL].first().astype(int)
            ba = balanced_accuracy_score(y_true, y_pred) if len(y_true) else -1.0
            
            # Calculate confidence: mean absolute deviation from 0.5
            ids_list = sorted(list(val_ids))
            p_ser = self._p_spk_softvote(int(spk), ids_list, val_ids, calib_res)
            confidence = float(np.mean(np.abs(p_ser.to_numpy() - 0.5)))
            
            # Regularized score
            reg_score = ba + self.cfg.args.confidence_weight * confidence
            
            logger.debug("Speaker %d: BA=%.4f, Confidence=%.4f, RegScore=%.4f", 
                        spk, ba, confidence, reg_score)

            pick = SpeakerPick(speaker=spk, calib=calib_res, score_ba=float(ba))
            if reg_score > best_score:
                best_score = reg_score
                best = pick

        if best is None:
            raise RuntimeError("Regularized speaker selection failed.")
        
        logger.info("Regularized selection: Speaker %d (BA=%.4f, RegScore=%.4f)",
                   best.speaker, best.score_ba, best_score)
        return best
    
    def _select_global_best_speaker_vote(self, val_ids: set) -> SpeakerPick:
        best = None
        for spk in self.cfg.targets:
            spk = int(spk)
            df_vc = self.loader.load(self.cfg.args.domain_b, self.cfg.args.conversion_model, spk)
            if df_vc is None or df_vc.empty:
                continue
            df_vc_val = df_vc[df_vc["record_id"].isin(val_ids)].copy()
            if df_vc_val.empty:
                continue

            df_inf = self.opensmile.infer_rows(df_vc_val)
            calib_res = self.calib.calibrate_vote(df_inf, "prob")

            tmp = df_inf.copy()
            tmp["seg_pred"] = (tmp["prob"] >= calib_res.threshold).astype(int)
            counts = tmp.groupby("record_id")["seg_pred"].sum()
            y_pred = (counts >= calib_res.tau).astype(int)
            y_true = tmp.groupby("record_id")[self.cfg.TARGET_LABEL].first().astype(int)
            ba = balanced_accuracy_score(y_true, y_pred) if len(y_true) else -1.0

            pick = SpeakerPick(speaker=spk, calib=calib_res, score_ba=float(ba))
            if best is None or pick.score_ba > best.score_ba:
                best = pick

        if best is None:
            raise RuntimeError("Global speaker selection failed.")
        return best

    def _speaker_vote_ba_map(self, val_ids: set) -> Dict[int, float]:
        out = {}
        for spk in self.cfg.targets:
            spk = int(spk)
            df_vc = self.loader.load(self.cfg.args.domain_b, self.cfg.args.conversion_model, spk)
            if df_vc is None or df_vc.empty:
                continue
            df_vc_val = df_vc[df_vc["record_id"].isin(val_ids)].copy()
            if df_vc_val.empty:
                continue
            df_inf = self.opensmile.infer_rows(df_vc_val)
            calib_res = self.calib.calibrate_vote(df_inf, "prob")

            tmp = df_inf.copy()
            tmp["seg_pred"] = (tmp["prob"] >= calib_res.threshold).astype(int)
            counts = tmp.groupby("record_id")["seg_pred"].sum()
            y_pred = (counts >= calib_res.tau).astype(int)
            y_true = tmp.groupby("record_id")[self.cfg.TARGET_LABEL].first().astype(int)
            if len(y_true):
                out[spk] = float(balanced_accuracy_score(y_true, y_pred))
        return out

    def _speaker_calibs_on_ids(self, ids_set: set, speakers: List[int]) -> Dict[int, CalibResult]:
        out = {}
        for spk in speakers:
            spk = int(spk)
            df_vc = self.loader.load(self.cfg.args.domain_b, self.cfg.args.conversion_model, spk)
            if df_vc is None or df_vc.empty:
                continue
            df_sub = df_vc[df_vc["record_id"].isin(ids_set)].copy()
            if df_sub.empty:
                continue
            df_inf = self.opensmile.infer_rows(df_sub)
            out[spk] = self.calib.calibrate_vote(df_inf, "prob")
        return out

    def _p_spk_softvote(
        self,
        spk: int,
        ids_list: List[str],
        ids_set: set,
        calib_res: CalibResult,
    ) -> pd.Series:
        spk = int(spk)
        df_vc = self.loader.load(self.cfg.args.domain_b, self.cfg.args.conversion_model, spk)
        if df_vc is None or df_vc.empty:
            return pd.Series(0.5, index=ids_list)
        df_sub = df_vc[df_vc["record_id"].isin(ids_set)].copy()
        if df_sub.empty:
            return pd.Series(0.5, index=ids_list)

        df_inf = self.opensmile.infer_rows(df_sub)

        seg_counts = df_inf.groupby("record_id").size()
        s_fold = float(np.median(np.sqrt(seg_counts.values))) if len(seg_counts) else 1.0
        s_fold = max(s_fold, 1.0)

        return record_soft_vote_prob(
            df_inf=df_inf,
            record_ids=ids_list,
            threshold=calib_res.threshold,
            tau=calib_res.tau,
            s=s_fold,
            prob_col="prob",
        ).astype(float)

    def _predict_global_prob_mean(self, ids_set: set, global_pick: SpeakerPick) -> Tuple[pd.Series, pd.Series]:
        df_vc = self.loader.load(self.cfg.args.domain_b, self.cfg.args.conversion_model, int(global_pick.speaker))
        if df_vc is None or df_vc.empty:
            raise RuntimeError("Global baseline VC missing.")
        df_sub = df_vc[df_vc["record_id"].isin(ids_set)].copy()
        df_inf = self.opensmile.infer_rows(df_sub)
        p = df_inf.groupby("record_id")["prob"].mean()
        y = df_inf.groupby("record_id")[self.cfg.TARGET_LABEL].first().astype(int)
        ids_list = sorted(list(ids_set))
        return y.reindex(ids_list), p.reindex(ids_list).fillna(0.5)

    # ---------- Routing mode: learned_gate ----------

    def _train_gate_svm(
        self,
        df_raw_b: pd.DataFrame,
        train_ids: set,
        speakers: List[int],
        speaker_calibs: Dict[int, CalibResult],
        global_speaker: Optional[int] = None,
    ) -> Any:
        # Use SVC instead of LogisticRegression
        # We need to import SVC inside or at top.
        from sklearn.svm import SVC

        df_rec = self._record_level_embeddings(df_raw_b, speaker=global_speaker)
        ids_list = sorted(list(train_ids))
        df_tr = df_rec.set_index("record_id").reindex(ids_list).reset_index()
        y_true = df_tr[self.cfg.TARGET_LABEL].astype(int).to_numpy()

        emb_cols = [c for c in df_tr.columns if c.startswith("emb_")]
        E_x = df_tr[emb_cols].to_numpy(dtype=np.float32)
        E_x = l2_normalize(E_x, axis=1)

        # 1. Compute expert correctness scores for each record
        # Score_s(x) = p_s(x) if y=1 else 1-p_s(x)
        # We want to pick the expert that maximizes this likelihood.
        n = len(ids_list)
        m = len(speakers)
        scores = np.zeros((n, m), dtype=np.float64)

        for j, spk in enumerate(speakers):
            calib_res = speaker_calibs.get(int(spk), CalibResult(0.5, self.cfg.DEFAULT_TAU, 0.5))
            p_ser = self._p_spk_softvote(int(spk), ids_list, train_ids, calib_res)
            p_val = p_ser.to_numpy(dtype=np.float64)
            
            # if y=1, score=p. if y=0, score=1-p.
            # Vectorized: score = y*p + (1-y)*(1-p)
            s_vec = y_true * p_val + (1 - y_true) * (1.0 - p_val)
            scores[:, j] = s_vec

        # 2. Target for SVM: index of best expert
        best_expert_idx = np.argmax(scores, axis=1) # (n,)

        # 3. Train SVM
        # We use probability=True to get soft weights later
        svm = SVC(
            kernel="rbf",
            class_weight="balanced",
            probability=True,
            decision_function_shape="ovr",
            random_state=self.cfg.RANDOM_SEED
        )
        svm.fit(E_x, best_expert_idx)
        return svm

    def _predict_learned_gate(
        self,
        df_raw_b: pd.DataFrame,
        ids_set: set,
        speakers: List[int],
        gate: Any, # SVC
        speaker_calibs: Dict[int, CalibResult],
        global_speaker: Optional[int] = None,
    ) -> Tuple[pd.Series, pd.Series]:
        """
        Gate now returns probabilities over experts (classes).
        We use these directly as mixing weights.
        """
        df_rec = self._record_level_embeddings(df_raw_b, speaker=global_speaker)
        ids_list = sorted(list(ids_set))
        df_ev = df_rec.set_index("record_id").reindex(ids_list).reset_index()
        y_true = df_ev[self.cfg.TARGET_LABEL].astype(int)
        y_true.index = ids_list

        emb_cols = [c for c in df_ev.columns if c.startswith("emb_")]
        E_x = df_ev[emb_cols].to_numpy(dtype=np.float32)
        E_x = l2_normalize(E_x, axis=1)
        n = E_x.shape[0]

        # SVM predict_proba -> (n, m)
        # Note: SVM classes might be sorted differently if not 0..m-1 present in train.
        # But we force 0..m-1 indices in training, so usually safe. 
        # However, to be extra safe, we map via gate.classes_
        
        raw_probs = gate.predict_proba(E_x) # (n, n_classes_in_train)
        
        # Map back to full speaker list slots
        W = np.zeros((n, len(speakers)), dtype=np.float64)
        for col_idx, class_label in enumerate(gate.classes_):
            if class_label < len(speakers):
                W[:, class_label] = raw_probs[:, col_idx]

        # If some classes were never best in train, their weight is 0.

        # Compute Expert Probs P
        P = np.full((n, len(speakers)), 0.5, dtype=np.float64)
        for j, spk in enumerate(speakers):
            calib_res = speaker_calibs.get(int(spk), CalibResult(0.5, self.cfg.DEFAULT_TAU, 0.5))
            p_ser = self._p_spk_softvote(int(spk), ids_list, ids_set, calib_res)
            P[:, j] = p_ser.to_numpy(dtype=np.float64)

        # Weighted sum
        p_final = (W * P).sum(axis=1)
        return y_true, pd.Series(p_final, index=ids_list, name="p_gate")


    # ---------- OOS val blend predictions for threshold tuning ----------

    def _oos_val_blend_predictions(
        self,
        df_raw_b: pd.DataFrame,
        outer_val_ids: set,
        global_pick: SpeakerPick,
        spk_cache: Optional[SpeakerEmbeddingCache],
        n_inner_folds: int,
    ) -> Tuple[pd.Series, pd.Series]:
        val_list = sorted(list(outer_val_ids))
        df_rec = self._record_level_embeddings(df_raw_b, speaker=global_pick.speaker).set_index("record_id").reindex(val_list)
        y_all = df_rec[self.cfg.TARGET_LABEL].astype(int)
        y_np = y_all.to_numpy()

        skf = StratifiedKFold(n_splits=int(n_inner_folds), shuffle=True, random_state=self.cfg.RANDOM_SEED)
        p_out = pd.Series(index=val_list, dtype=float)

        for tr_idx, ev_idx in skf.split(np.arange(len(val_list)), y_np):
            tr_ids = set([val_list[i] for i in tr_idx])
            ev_ids = set([val_list[i] for i in ev_idx])

            # Global probs for blending
            y_g, p_g = self._predict_global_prob_mean(ev_ids, global_pick)

            # --- Learned Gate Logic ---
            # shortlist top-K on inner-train
            spk_ba = self._speaker_vote_ba_map(tr_ids)
            speakers_sorted = sorted(spk_ba.items(), key=lambda x: x[1], reverse=True)
            K = int(self.cfg.args.gate_topk)
            speakers = [int(s) for s, _ in speakers_sorted[:K]]
            if len(speakers) < 2:
                speakers = [int(self.cfg.targets[0])]

            spk_ids, E_spk = spk_cache.load_or_build(speakers)

            # train gate on inner-train
            spk_calibs_tr = self._speaker_calibs_on_ids(tr_ids, spk_ids)
            gate = self._train_gate_svm(df_raw_b, tr_ids, spk_ids, spk_calibs_tr, global_speaker=global_pick.speaker)

            # predict on inner-eval
            spk_calibs_ev = self._speaker_calibs_on_ids(tr_ids, spk_ids)
            y_r, p_r = self._predict_learned_gate(df_raw_b, ev_ids, spk_ids, gate, spk_calibs_ev, global_speaker=global_pick.speaker)

            common = p_r.index.intersection(p_g.index)
            beta = float(self.cfg.args.global_blend)
            p_blend = (1.0 - beta) * p_g.loc[common] + beta * p_r.loc[common]
            p_out.loc[common] = p_blend

        return y_all, p_out.fillna(0.5).astype(float)

    # ---------- Run ----------

    def run(self):
        # Train OpenSMILE on source
        df_source = self.loader.load(self.cfg.args.domain_a)
        if df_source is None or df_source.empty:
            raise ValueError("Source domain data missing/empty")
        self.opensmile.train(df_source)

        # Load target RAW
        df_raw_b = self.loader.load(self.cfg.args.domain_b)
        if df_raw_b is None or df_raw_b.empty:
            raise ValueError("Target RAW data missing/empty")

        # Start ECAPA loading for learned_gate
        self._ensure_ecapa()
        spk_cache = SpeakerEmbeddingCache(self.cfg, self.ecapa)

        subj_ids = df_raw_b["record_id"].unique()
        subj_y = subject_labels(df_raw_b, self.cfg.TARGET_LABEL).reindex(subj_ids).values.astype(int)

        outer = StratifiedKFold(
            n_splits=int(self.cfg.args.outer_folds),
            shuffle=True,
            random_state=self.cfg.RANDOM_SEED,
        )

        rows_out: List[Dict[str, Any]] = []
        all_moe_preds: List[pd.DataFrame] = []
        all_base_preds: List[pd.DataFrame] = []

        for split_idx, (val_idx, test_idx) in enumerate(outer.split(subj_ids, subj_y), start=1):
            val_ids = set(subj_ids[val_idx].tolist())
            test_ids = set(subj_ids[test_idx].tolist())

            logger.info("======================================================")
            logger.info("Outer split %d: val=%d test=%d | routing=learned_gate", split_idx, len(val_ids), len(test_ids))
            logger.info("======================================================")

            # Global baseline: best speaker on outer-val by vote BA
            if self.cfg.args.regularize_speaker_selection:
                global_pick = self._regularized_speaker_selection(val_ids)
            else:
                global_pick = self._select_global_best_speaker_vote(val_ids)
            logger.info("Global best speaker: %d | BA=%.4f | thr=%.3f tau=%d",
                        global_pick.speaker, global_pick.score_ba,
                        global_pick.calib.threshold, global_pick.calib.tau)
            logger.info("Gate embeddings from: %s audio (speaker=%s)",
                        "CONVERTED" if self.cfg.args.gate_use_converted else "RAW",
                        global_pick.speaker if self.cfg.args.gate_use_converted else "N/A")

            # Tune final threshold on outer-val (OOS)
            y_val_true, p_val_blend_oos = self._oos_val_blend_predictions(
                df_raw_b=df_raw_b,
                outer_val_ids=val_ids,
                global_pick=global_pick,
                spk_cache=spk_cache,
                n_inner_folds=int(self.cfg.args.inner_folds_thr),
            )
            if self.cfg.args.no_calibration:
                thr_final = 0.5
                yp_val = (p_val_blend_oos >= 0.5).astype(int)
                ba_val_oos = balanced_accuracy_score(y_val_true, yp_val) if len(y_val_true) else 0.0
            else:
                thr_final, ba_val_oos = tune_final_threshold_ba(y_val_true, p_val_blend_oos, n_grid=int(self.cfg.args.final_thr_grid))
            logger.info("Final threshold: thr=%.3f | BA=%.4f", thr_final, ba_val_oos)

            # Predict on test
            y_g, p_g = self._predict_global_prob_mean(test_ids, global_pick)

            # --- Learned Gate logic for Test ---
            spk_ba = self._speaker_vote_ba_map(val_ids)
            speakers_sorted = sorted(spk_ba.items(), key=lambda x: x[1], reverse=True)
            K = int(self.cfg.args.gate_topk)
            speakers = [int(s) for s, _ in speakers_sorted[:K]]
            if len(speakers) < 2:
                speakers = [int(self.cfg.targets[0])]

            spk_ids, E_spk = spk_cache.load_or_build(speakers)

            spk_calibs_val = self._speaker_calibs_on_ids(val_ids, spk_ids)
            gate = self._train_gate_svm(df_raw_b, val_ids, spk_ids, spk_calibs_val, global_speaker=global_pick.speaker)
            y_r, p_r = self._predict_learned_gate(df_raw_b, test_ids, spk_ids, gate, spk_calibs_val, global_speaker=global_pick.speaker)
            
            common = p_r.index.intersection(p_g.index)
            beta = float(self.cfg.args.global_blend)
            p_blend = (1.0 - beta) * p_g.loc[common] + beta * p_r.loc[common]
            y_pred = (p_blend >= thr_final).astype(int)

            ba_routed = balanced_accuracy_score(y_r.loc[common], y_pred)
            f1_routed = f1_score(y_r.loc[common], y_pred, average="macro")

            # Baseline vote BA on test
            df_vc = self.loader.load(self.cfg.args.domain_b, self.cfg.args.conversion_model, int(global_pick.speaker))
            df_vc_test = df_vc[df_vc["record_id"].isin(test_ids)].copy()
            df_inf_test = self.opensmile.infer_rows(df_vc_test)
            tmp = df_inf_test.copy()
            tmp["seg_pred"] = (tmp["prob"] >= global_pick.calib.threshold).astype(int)
            counts = tmp.groupby("record_id")["seg_pred"].sum()
            yb_pred = (counts >= global_pick.calib.tau).astype(int)
            yb_true = tmp.groupby("record_id")[self.cfg.TARGET_LABEL].first().astype(int)
            ba_base = balanced_accuracy_score(yb_true, yb_pred)
            f1_base = f1_score(yb_true, yb_pred, average="macro")

            logger.info("Split %d | Routed+Blend BA=%.4f | thr=%.3f", split_idx, ba_routed, thr_final)
            logger.info("Split %d | Baseline BA=%.4f", split_idx, ba_base)
            # Save per-record preds
            fold_pred = pd.DataFrame({
                "record_id": list(common),
                "y_true": y_r.loc[common].values,
                "p_blend": p_blend.loc[common].values,
                "p_routed": p_r.loc[common].values,
                "p_global": p_g.loc[common].values,
                "y_pred": y_pred.loc[common].values,
            })
            out_pred = self.cfg.output_dir / f"fold_{split_idx:02d}_preds.csv"
            fold_pred.to_csv(out_pred, index=False)

            # Collect pooled preds for MoE
            df_moe_fold = pd.DataFrame({
                "record_id": list(common),
                "prediction": y_pred.loc[common].values,
                "prediction_prob": p_r.loc[common].values,
                "label": y_r.loc[common].values
            })
            all_moe_preds.append(df_moe_fold)

            # Collect pooled preds for Baseline
            yb_pred_common = yb_pred.reindex(common).dropna()
            yb_true_common = yb_true.reindex(common).dropna()
            common_base = yb_pred_common.index
            
            df_base_fold = pd.DataFrame({
                "record_id": list(common_base),
                "prediction": yb_pred_common.values.astype(int),
                "prediction_prob": p_g.loc[common_base].values,
                "label": yb_true_common.values.astype(int)
            })
            all_base_preds.append(df_base_fold)

            rows_out.append({
                "Split": split_idx,
                "n_val": len(val_ids),
                "n_test": len(test_ids),
                "gate_topk": int(self.cfg.args.gate_topk),
                "gate_features": self.cfg.args.gate_features,
                "global_blend": float(beta),
                "thr_final": float(thr_final),
                "BA_routed_blend": float(ba_routed),
                "F1_routed_blend": float(f1_routed),
                "BA_baseline_vote": float(ba_base),
                "F1_baseline_vote": float(f1_base),
                "Delta_BA_minus_baseline": float(ba_routed - ba_base),
                "baseline_speaker": int(global_pick.speaker),
                "baseline_thr": float(global_pick.calib.threshold),
                "baseline_tau": int(global_pick.calib.tau),
            })

        df_out = pd.DataFrame(rows_out)
        mean_row = df_out.mean(numeric_only=True).to_dict()
        mean_row["Split"] = "Mean"
        
        # Calculate standard deviations for final results
        std_row = df_out.std(numeric_only=True).to_dict()
        mean_row["BA_routed_blend_std"] = std_row.get("BA_routed_blend", float("nan"))
        mean_row["BA_baseline_vote_std"] = std_row.get("BA_baseline_vote", float("nan"))
        
        df_out = pd.concat([df_out, pd.DataFrame([mean_row])], ignore_index=True)

        out_path = self.cfg.output_dir / "results_routed_vs_global.csv"
        df_out.to_csv(out_path, index=False)

        logger.info("======================================================")
        logger.info("Saved summary results: %s", out_path)
        logger.info("Mean BA Routed+Blend: %.4f (std=%.4f)", mean_row.get("BA_routed_blend", float("nan")), mean_row.get("BA_routed_blend_std", float("nan")))
        logger.info("Mean BA Baseline:     %.4f (std=%.4f)", mean_row.get("BA_baseline_vote", float("nan")), mean_row.get("BA_baseline_vote_std", float("nan")))

        # Save pooled predictions
        if all_moe_preds:
            df_pool_moe = pd.concat(all_moe_preds, ignore_index=True)
            p_moe_path = self.cfg.output_dir / "pooled_moe_predictions.csv"
            df_pool_moe.to_csv(p_moe_path, index=False)
            logger.info("Saved pooled MoE preds: %s (n=%d)", p_moe_path, len(df_pool_moe))

        if all_base_preds:
            df_pool_base = pd.concat(all_base_preds, ignore_index=True)
            p_base_path = self.cfg.output_dir / "pooled_baseline_predictions.csv"
            df_pool_base.to_csv(p_base_path, index=False)
            logger.info("Saved pooled Baseline preds: %s (n=%d)", p_base_path, len(df_pool_base))

        logger.info("======================================================")


if __name__ == "__main__":
    cfg = ExperimentConfig()
    setup_logging(log_file=cfg.output_dir / "routing_log.txt")
    exp = RoutedOpenSmileVoteExperiment(cfg)
    exp.run()
